#ifndef MATERIAS_H
#define MATERIAS_H


class Materias
{
    public:
        Materias();
    protected:
    private:
};

#endif // MATERIAS_H
