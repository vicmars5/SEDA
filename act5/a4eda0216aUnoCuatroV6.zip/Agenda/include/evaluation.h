#ifndef EVALUATION_H
#define EVALUATION_H


class Evaluation
{
    public:
        void menu();
    protected:
    private:
};

#endif // EVALUATION_H
