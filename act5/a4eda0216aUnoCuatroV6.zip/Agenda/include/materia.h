#ifndef MATERIA_H
#define MATERIA_H


struct Materia {

public:
    //Entrada de datos
    char    nombreMateria[25],
            acronimo[5],
            horario[8];

};

#endif // MATERIA_H
