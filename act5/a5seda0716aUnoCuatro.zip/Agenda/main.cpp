/*
 * Actividad V. Almacenamiento Secundario
 * UnoCuatro
 * Tiempo=08:20
 *
 */

#include <iostream>
#include <cstdlib>

#include "signatureView.h"
#include "homeworkView.h"
#include "evaluation.h"
#include "diaryView.h"

#ifdef __unix__
#define CLEAR "clear"
#else
#define CLEAR "cls"
#endif

#define OP_COURSE_EVAL 1 //Option: course evaluation
#define OP_SUBJ_MNG 2 //Option: subjects managment
#define OP_HWORK_MNG 3 //Option: homework managment
#define OP_DIARY 4//Option: diary
#define EXIT 5 //Option: exit

using namespace std;

int main() {
    int op;

    SignatureView signatures;
    HomeworkView homeworks;
    Evaluation evaluation;
    DiaryView diaries;

    do {
        system(CLEAR);
        cout << "\tMEN\u00DA PRINCIPAL" << endl
             << " 1. Evaluaci\u00F3n del curso" << endl
             << " 2. Gesti\u00F3n de materias" << endl
             << " 3. Gesti\u00F3n de tareas" << endl
             << " 4. Agenda" << endl
             << " 5. Salir" << endl
             << " Opci\u00F3n: ";
        cin >> op;
        cin.ignore();

        switch(op) {
        case OP_COURSE_EVAL:
            evaluation.menu();
            break;

        case OP_SUBJ_MNG:
            signatures.showMenu();
            break;

        case OP_HWORK_MNG:
            homeworks.showMenu();
            break;
        case OP_DIARY:
            diaries.showMenu();
            break;
        case EXIT:
            break;

        default:
            break;
        }

    } while(op != EXIT);

    return 0;
}
