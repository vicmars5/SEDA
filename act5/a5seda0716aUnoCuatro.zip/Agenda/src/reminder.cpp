#include "reminder.h"

Reminder::Reminder() {
    subject = "";
    type = "";
    date = "";
    hour = "";
}

void Reminder::setSubject(const string& s) {
    subject = s;
}

void Reminder::setType(const string& t) {
    type = t;
}

void Reminder::setDate(const string& d) {
    date = d;
}

void Reminder::setHour(const string& h) {
    hour = h;
}

string& Reminder::getSubject() {
    return subject;
}

string& Reminder::getType() {
    return type;
}

string& Reminder::getDate() {
    return date;
}

string& Reminder::getHour() {
    return hour;
}

bool Reminder::operator==(const Reminder& a) const {
    return (this->subject == a.subject);
}

ostream& operator << (ostream& o, const Reminder& a){
    o << a.subject << endl
        << a.type << endl
        << a.date << endl
        << a.hour << endl;

    return o;
}

istream& operator >> (istream& i, Reminder& a){
    string str;

    if(getline(i, str))
        a.subject = str;
    if(getline(i, str))
        a.type = str;
    if(getline(i, str))
        a.date = str;
    if(getline(i, str))
        a.hour = str;

    return i;
}
