#include "diaryView.h"


DiaryView::DiaryView() {
    change = false;
}

void DiaryView::showMenu() {
    unsigned short op;

    do {
        system(CLEAR);
        cout << "\tAgenda" << endl;
        cout << " 1.- Agregar recordatorio" << endl
             << " 2.- Listar recordatorio" << endl
             << " 3.- Mostrar detalles de un recordatorio" << endl
             << " 4.- Modificar una tarea" << endl
             << " 5.- Eliminar recordatorio" << endl
             << " 6.- Guardar recordatorio" << endl
             << " 7.- Regresar al men\u00FA anterior" << endl
             << " Elige una opci\u00F3n: ";
        cin >> op;
        cin.ignore();
        cout << endl;

        switch(op) {
        case ADD:
            add();
            break;
        case LIST:
            listD();
            break;
        case SAVE:
            save();
            break;
        case SHOW:
            show();
            break;
        case DLT:
            del();
            break;
        case EDIT:
            edit();
            break;
        case EXIT:
            break;
        default:
            break;
        }

    } while(op != EXIT);
}

void DiaryView::add() {
    Reminder r;
    string txt;
    system(CLEAR);
    cout << "\t A\u00F1adiendo " << endl;

    cout << "Asunto: ";
    getline(cin, txt);
    r.setSubject(txt);

    cout << "Tipo: ";
    getline(cin, txt);
    r.setType(txt);

    cout << "Fecha: ";
    getline(cin, txt);
    r.setDate(txt);

    cout << "Hora: ";
    getline(cin, txt);
    r.setHour(txt);

    try {
        diary.add(r);
    } catch(ArrayListException ex) {
        cout << "No se pudo guardar" << endl;
        return;
    }

    change = true; //The reminder list was changed
    cout << "Se guardo el recordatorio... " << endl;
    cin.get();
}

void DiaryView::listD() {
    Reminder r;

    system(CLEAR);
    cout << "\tRecordatorios" << endl << endl;
    try {
        for(int i = 0; i < diary.length(); i++) {
            r = diary.get(i);
            print(r);
        }
    } catch(ArrayListException ex) {
        cout << "No se pudieron leer los datos. " << ex.what() << endl;
    }

    cin.get();
}

void DiaryView::show() {
    Reminder r;
    string txt;
    int pos;

    system(CLEAR);

    cout << "\tMostrar detalle de un recordatorio" << endl; ///Ask to the teacher if "Mostrar detalles de recordatorio" is better
    cout << " Asunto del recordatorio: ";
    getline(cin, txt);
    cout << endl;
    r.setSubject(txt);

    pos = diary.findD(r);

    if(pos >= 0) {
        try {
            r = diary.get(pos);
        } catch(ArrayListException ex) {
            cout << " No se pudo obtener el recordatorio. " << endl << endl;
            cin.get();
            return;
        }

        print(r);

    } else {
        cout << " No se encontro el recordatorio. " << endl << endl;
    }

    cin.get();
}

void DiaryView::edit() {
    Reminder r;
    string txt;
    int pos;

    cout << "\tModificar recordatorio" << endl;
    cout << "Asunto del recordatorio: ";
    getline(cin, txt);

    r.setSubject(txt);
    pos = diary.findD(r);

    if(pos >= 0) {
        try {
            r = diary.get(pos);
        } catch(ArrayListException ex) {
            cout << "Error al obtener el recordatorio. " << endl;
            cin.get();
            return;
        }

        print(r);
        cout << endl;

        cout << "Asunto: ";
        getline(cin, txt);
        r.setSubject(txt);

        cout << "Tipo: ";
        getline(cin, txt);
        r.setType(txt);

        cout << "Fecha: ";
        getline(cin, txt);
        r.setDate(txt);

        cout << "Hora: ";
        getline(cin, txt);
        r.setHour(txt);

        try {
            diary.edit(pos, r);
            cout << "Datos guardados" << endl;
            print(r);
        } catch(ArrayListException ex) {
            cout << " No se pudieron guardar los cambios." << endl;
        }
    } else {
        cout << "No se encontro el recordatorio. " << endl;
        cin.get();
    }
}

void DiaryView::del() {
    Reminder r;
    string txt;
    int pos;

    system(CLEAR);

    cout << "\tEliminar recordatorio" << endl;
    cout << " Asunto del recordatorio: ";
    getline(cin, txt);
    cout << endl;
    r.setSubject(txt);

    pos = diary.findD(r);

    if(pos >= 0) {
        try {
            r = diary.get(pos);
        } catch(ArrayListException ex) {
            cout << " No se pudo obtener el recordatorio. " << endl;
            cin.get();
            return;
        }

        print(r);

        try {
            diary.del(pos);
            cout << " El recordatorio fue eliminado. " << endl;
        } catch(ArrayListException ex) {
            cout << " No se pudo eliminar el recordatorio." << endl;
        }

    } else {
        cout << " No se encontro el recordatorio. " << endl << endl;
    }
    cout << " Presione entrar para continuar..." << endl;
    cin.get();
}

void DiaryView::save() {
    try {
        diary.save(DRV_FILE);
    } catch(ArrayListException ex) {
        cout << " No se pudo guardar los cambios." << endl;
    }
}

void DiaryView::print(Reminder& r) {
    cout << " Asunto: " << r.getSubject() << endl
         << " Tipo: " << r.getType() << endl
         << " Fecha: " << r.getDate() << endl
         << " Hora: " << r.getHour() << endl << endl;
}
