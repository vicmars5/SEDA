#ifndef REMINDER_H
#define REMINDER_H

#include <string>
#include <iostream>

using namespace std;

class Reminder {
private:
    string subject;
    string type;
    string date;
    string hour;
public:
    Reminder();

    void setSubject(const string& s);
    void setType(const string& t);
    void setDate(const string& d);
    void setHour(const string& h);

    string& getSubject();
    string& getType();
    string& getDate();
    string& getHour();

    bool operator == (const Reminder& a) const;

    friend ostream& operator << (ostream& o, const Reminder& a);
    friend istream& operator >> (istream& i, Reminder& a);
};

#endif // REMINDER_H
