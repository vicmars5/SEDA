#ifndef DIARYVIEW_H
#define DIARYVIEW_H

#include <string>
#include <iostream>
#include <cstdlib>

#include "arrayList.h"
#include "reminder.h"

#ifdef __unix__
#define CLEAR "clear"
#else
#define CLEAR "cls"
#endif


#define DRV_FILE "diary.txt"

enum MENU_OPTS {ADD = 1, LIST, SAVE, SHOW, DLT, EDIT, EXIT};

class DiaryView {
private:
    ArrayList<Reminder> diary;
    bool change;

    void add();
    void listD();
    void show();
    void edit();
    void del();
    void save();

    void print(Reminder& r);
public:
    DiaryView();
    void showMenu();
};

#endif // DIARYVIEW_H
