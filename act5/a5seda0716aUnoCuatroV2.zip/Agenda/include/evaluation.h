#ifndef EVALUATION_H
#define EVALUATION_H

#include "materia.h"

#ifdef __unix__
#define CLEAR "clear"
#else
#define CLEAR "cls"
#endif

//Porcentaje a considerar para evaluacion del curso
#define VAL_TAREAS 7
#define VAL_ACTIVIDADES 63
#define VAL_EXA_PARCIALES 30

//Total de los evaluandos y asistencias
#define TTL_ASISTENCIAS 34
#define TTL_TAREAS 10
#define TTL_ACTIVIDADES 9
#define TTL_EXA_PARCIALES 3

#define RETARDOS_POR_FALTA 3 //Cada tres retardos es un falta
#define ASISTENCIA_MIN 80 //Porcentaje minimo de asistencia para aprovar
#define CAL_MAX 100 //Calificiones van del 0 al 100
#define CAL_MIN_APROV 60 //Calificacion minima aprovatoria

#define ESCALA_EVALUACION 100 //Se evalua hasta el cien

using namespace std;

class Evaluation {
private:
    //Entrada de datos
    float   faltas, //Faltas a clase
            retardos, //Retardos a clase
            tareas; //Tareas realizadas
    float   calsActividades[TTL_ACTIVIDADES], //Calificaciones de actividades
            calsExaParciales[TTL_EXA_PARCIALES]; //Calificaciones de examenes parciales
    //Salida de datos
    //Puntajes
    float   ptsFlsTareas,
            ptsFlsActividades,
            ptsFlsExamenes,
            calFinal;

    //Asistencias
    float   asistencias, //Cantidad de asistencias
            porcAsistencias; //Porcentaje de asistencias
    //Afirmaciones
    bool    derechoOrdinario, //Derecho a ordinario
            calAprobatoria,
            aprobado;

    Materia materia;
public:
    void menu();

    void signForm(); // Signature form
    void evalForm(); // Evaluation form
    void compute();
    void showResults();
};

#endif // EVALUATION_H
